package org.switchnative

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    companion object {
        init { System.loadLibrary("switchnative") }
    }

    private external fun nativeGetStatus(): String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val title = TextView(this).apply {
            text = "SwitchNative"
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
        }
        val subtitle = TextView(this).apply {
            text = "Android • ARM64 • Vulkan"
            textSize = 14f
        }
        val status = TextView(this).apply {
            text = nativeGetStatus()
            textSize = 15f
            setTextIsSelectable(true)
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP
            setPadding(28, 40, 28, 28)
            addView(title)
            addView(subtitle)
            addView(status)
        }
        setContentView(ScrollView(this).apply { addView(layout) })
    }
}
