#include <jni.h>
#include <vulkan/vulkan.h>
#include <sstream>
#include <string>

static std::string vulkanStatus() {
    uint32_t version = VK_API_VERSION_1_0;
    auto enumerateVersion =
        reinterpret_cast<PFN_vkEnumerateInstanceVersion>(
            vkGetInstanceProcAddr(VK_NULL_HANDLE, "vkEnumerateInstanceVersion"));

    if (enumerateVersion != nullptr) {
        if (enumerateVersion(&version) != VK_SUCCESS) {
            return "Vulkan loader found, but version query failed.";
        }
    }

    uint32_t count = 0;
    VkResult result = vkEnumerateInstanceExtensionProperties(nullptr, &count, nullptr);
    if (result != VK_SUCCESS) {
        return "Vulkan loader found; extension enumeration failed.";
    }

    std::ostringstream out;
    out << "Vulkan loader: available\n";
    out << "Instance API: " << VK_VERSION_MAJOR(version) << "."
        << VK_VERSION_MINOR(version) << "."
        << VK_VERSION_PATCH(version) << "\n";
    out << "Instance extensions: " << count << "\n";
    out << "Native core: initialized\n";
    out << "\nThis is a foundation test, not a Switch game emulator yet.";
    return out.str();
}

extern "C" JNIEXPORT jstring JNICALL
Java_org_switchnative_MainActivity_nativeGetStatus(JNIEnv* env, jobject) {
    const std::string status = vulkanStatus();
    return env->NewStringUTF(status.c_str());
}
