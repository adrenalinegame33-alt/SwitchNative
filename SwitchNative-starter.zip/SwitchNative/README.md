# SwitchNative — Android native emulator research project

Starter project for an original Android/ARM64 emulator research codebase using Kotlin, C++20, JNI and Vulkan.

## What this first module does
- Starts a native C++ library from a Kotlin Android Activity.
- Queries the Android Vulkan loader and reports the instance API version and extension count.
- Restricts the initial Android build to `arm64-v8a`.

## What it does not do
This is **not yet a Nintendo Switch emulator**. It does not load games, implement the Switch CPU/GPU, provide firmware/keys, or run commercial titles. Those require substantial additional engineering and testing.

## Build without a local PC
1. Create a GitHub repository from this project and upload the files.
2. Open the repository's **Actions** tab.
3. Run **Android debug build** (or push to `main`).
4. Download the `SwitchNative-debug` artifact from the completed workflow.

The workflow builds a debug APK in GitHub's hosted runner. GitHub account access and internet are required. No Termux is needed.

## Next engineering milestone
Implement a small, independently testable ARM64 instruction interpreter and unit tests, then add a Vulkan device/physical-device capability probe. Do not add proprietary firmware, keys, or copyrighted game data to the repository.
